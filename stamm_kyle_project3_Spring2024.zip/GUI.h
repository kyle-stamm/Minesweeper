
#ifndef PROJECT_3_GUI_H
#define PROJECT_3_GUI_H

#include "Visual.h"
#include "UIComponent.h"
#include "Board.h"
#include "Button.h"
#include "Digits.h"
#include "TextElement.h"
#include "Scene.h"
#pragma once

#endif //PROJECT_3_GUI_H
