Name: Kyle Stamm
Section: 21712
UFL email: stamm.kyle@ufl.edu
System: Windows 11
Compiler: g++
SFML version: 2.5.1
IDE: CLion
Other notes: None